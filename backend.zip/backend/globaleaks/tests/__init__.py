import os.path

from globaleaks.settings import Settings

Settings.loglevel = None
TEST_DIR = os.path.dirname(__file__)
